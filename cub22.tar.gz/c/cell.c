#define NIL -1
int alloced_i=0;
int arr_car[0x20000];
int arr_cdr[0x20000];
int reset_cells() {
    alloced_i = -1;
}

int car(int x) {
    return arr_car[x];
}

int cdr(int x) {
    return arr_cdr[x];
}

int cons(int x, int y) {
    ++alloced_i;
    arr_car[alloced_i]=x;;
    arr_cdr[alloced_i]=y;;
    return alloced_i;
}

int null(int x) {
    return x==NIL;
}

int list(int x) {
    return cons(x,NIL);
}

int append(int cell1, int cell2) {
    if(null(cell1))return cell2;
    return cons(car(cell1),append(cdr(cell1),cell2));
}

int reverse(int cell) {
    if(null(cell)) {
        return NIL;
    };
    return append(reverse(cdr(cell)),list(car(cell)));
}

int copy_list(int cell) {
    if(null(cell))return NIL;
    return cons(car(cell),cdr(cell));
}

