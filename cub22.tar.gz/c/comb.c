int pack_perm(int *a,int n) {
    int x = 0;
    int i,j;
    for (i=0; i<n-1; i++) {
        for (j=i+1; j<n; j++)
            if (a[j] < a[i])
                x++;
        x *= n-i-1;
    }
    return x;
}

int unpack_perm(int x,int *a,int n) {
    int i,j;
    a[n-1]=0;
    for (i=n-2; i>= 0; i--) {
        a[i]= x%(n-i);
        x /= n-i;
        for (j=n-1; j>i; j--)
            if (a[j]>=a[i])a[j]++;
    }
}
