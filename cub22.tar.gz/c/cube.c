int the_cube[24];
int reset_cube(int *cube) {
    cube[URF]=face_color[U];
    cube[DFR]=face_color[D];
    cube[UBR]=face_color[U];
    cube[DRB]=face_color[D];
    cube[UFL]=face_color[U];
    cube[DLF]=face_color[D];
    cube[ULB]=face_color[U];
    cube[DBL]=face_color[D];
    cube[RFU]=face_color[R];
    cube[FRD]=face_color[F];
    cube[BRU]=face_color[B];
    cube[RBD]=face_color[R];
    cube[FLU]=face_color[F];
    cube[LFD]=face_color[L];
    cube[LBU]=face_color[L];
    cube[BLD]=face_color[B];
    cube[FUR]=face_color[F];
    cube[RDF]=face_color[R];
    cube[RUB]=face_color[R];
    cube[BDR]=face_color[B];
    cube[LUF]=face_color[L];
    cube[FDL]=face_color[F];
    cube[BUL]=face_color[B];
    cube[LDB]=face_color[L];
}

