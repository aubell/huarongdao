#define NOP -2

#define L 4
#define U 6
#define B 2
#define R 3
#define D 1
#define F 5

#define EIGHT 8

#define RED 0xFF0000
#define BLUE 0x0000FF
#define YELLOW 0xF7F7F7
#define GREEN 0x00FF00
#define ORANGE 0xFF6600
#define WHITE 0xFFFFFF

int face_color[EIGHT];

int reset_colors() {
    face_color[U]=YELLOW;
    face_color[D]=WHITE;
    face_color[F]=GREEN;
    face_color[B]=BLUE;
    face_color[L]=RED;
    face_color[R]=ORANGE;
}

