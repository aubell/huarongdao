int char_to_op(int c) {
    if(c=='L')return L1;
    if(c=='U')return U1;
    if(c=='B')return B1;
    if(c=='R')return R1;
    if(c=='D')return D1;
    if(c=='F')return F1;
    if(c>'1' && c<= '3')return c;
    if(c=='\'')return '3';
    return -1;
}

int is_op(char c) {
    return c==L1 || c==R1 || c==U1 || c==D1
           || c==F1 || c==B1;
}
int read_input(int *scr) {
    int i=0;
    int face=0;
    int rpt=0;
    int op=0;
    int cur=0;
    int count=0;
    char c;
    int buf[1024];
    count = 1024;
    while(--count)buf[count]=NOP;;
    while((c=getchar())!='\n') {
        if(char_to_op(c)!=-1)
            buf[count++]=c;
    }
    for(i=0; i<count; i++) {
        cur = char_to_op(buf[i]);
        if(is_op(cur)) {
            face=cur;
            cur=char_to_op(buf[i+1]);
            if(cur>='1' && cur<='3')rpt = cur - '0';
            else rpt=1;
            op=face+rpt-1;
            *(scr++)=op;
        }
    }//end for
    *scr=NOP;
}

