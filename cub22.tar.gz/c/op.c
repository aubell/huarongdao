#define R1 1
#define R2 2
#define R3 3
#define U1 4
#define U2 5
#define U3 6
#define F1 7
#define F2 8
#define F3 9
#define L1 10
#define L2 11
#define L3 12
#define D1 13
#define D2 14
#define D3 15
#define B1 16
#define B2 17
#define B3 18

int* base_op_L(int *lp_cube) {
    int temp_value;
    temp_value=lp_cube[BUL];
    lp_cube[BUL]=lp_cube[DBL];
    lp_cube[DBL]=lp_cube[FDL];
    lp_cube[FDL]=lp_cube[UFL];
    lp_cube[UFL]=temp_value;
    temp_value=lp_cube[LBU];
    lp_cube[LBU]=lp_cube[LDB];
    lp_cube[LDB]=lp_cube[LFD];
    lp_cube[LFD]=lp_cube[LUF];
    lp_cube[LUF]=temp_value;
    temp_value=lp_cube[ULB];
    lp_cube[ULB]=lp_cube[BLD];
    lp_cube[BLD]=lp_cube[DLF];
    lp_cube[DLF]=lp_cube[FLU];
    lp_cube[FLU]=temp_value;
    return lp_cube;
}
int* base_op_U(int *lp_cube) {
    int temp_value;
    temp_value=lp_cube[UBR];
    lp_cube[UBR]=lp_cube[ULB];
    lp_cube[ULB]=lp_cube[UFL];
    lp_cube[UFL]=lp_cube[URF];
    lp_cube[URF]=temp_value;
    temp_value=lp_cube[RUB];
    lp_cube[RUB]=lp_cube[BUL];
    lp_cube[BUL]=lp_cube[LUF];
    lp_cube[LUF]=lp_cube[FUR];
    lp_cube[FUR]=temp_value;
    temp_value=lp_cube[BRU];
    lp_cube[BRU]=lp_cube[LBU];
    lp_cube[LBU]=lp_cube[FLU];
    lp_cube[FLU]=lp_cube[RFU];
    lp_cube[RFU]=temp_value;
    return lp_cube;
}
int* base_op_B(int *lp_cube) {
    int temp_value;
    temp_value=lp_cube[RBD];
    lp_cube[RBD]=lp_cube[DBL];
    lp_cube[DBL]=lp_cube[LBU];
    lp_cube[LBU]=lp_cube[UBR];
    lp_cube[UBR]=temp_value;
    temp_value=lp_cube[DRB];
    lp_cube[DRB]=lp_cube[LDB];
    lp_cube[LDB]=lp_cube[ULB];
    lp_cube[ULB]=lp_cube[RUB];
    lp_cube[RUB]=temp_value;
    temp_value=lp_cube[BDR];
    lp_cube[BDR]=lp_cube[BLD];
    lp_cube[BLD]=lp_cube[BUL];
    lp_cube[BUL]=lp_cube[BRU];
    lp_cube[BRU]=temp_value;
    return lp_cube;
}
int* base_op_R(int *lp_cube) {
    int temp_value;
    temp_value=lp_cube[FRD];
    lp_cube[FRD]=lp_cube[DRB];
    lp_cube[DRB]=lp_cube[BRU];
    lp_cube[BRU]=lp_cube[URF];
    lp_cube[URF]=temp_value;
    temp_value=lp_cube[DFR];
    lp_cube[DFR]=lp_cube[BDR];
    lp_cube[BDR]=lp_cube[UBR];
    lp_cube[UBR]=lp_cube[FUR];
    lp_cube[FUR]=temp_value;
    temp_value=lp_cube[RDF];
    lp_cube[RDF]=lp_cube[RBD];
    lp_cube[RBD]=lp_cube[RUB];
    lp_cube[RUB]=lp_cube[RFU];
    lp_cube[RFU]=temp_value;
    return lp_cube;
}
int* base_op_D(int *lp_cube) {
    int temp_value;
    temp_value=lp_cube[DLF];
    lp_cube[DLF]=lp_cube[DBL];
    lp_cube[DBL]=lp_cube[DRB];
    lp_cube[DRB]=lp_cube[DFR];
    lp_cube[DFR]=temp_value;
    temp_value=lp_cube[FDL];
    lp_cube[FDL]=lp_cube[LDB];
    lp_cube[LDB]=lp_cube[BDR];
    lp_cube[BDR]=lp_cube[RDF];
    lp_cube[RDF]=temp_value;
    temp_value=lp_cube[LFD];
    lp_cube[LFD]=lp_cube[BLD];
    lp_cube[BLD]=lp_cube[RBD];
    lp_cube[RBD]=lp_cube[FRD];
    lp_cube[FRD]=temp_value;
    return lp_cube;
}
int* base_op_F(int *lp_cube) {
    int temp_value;
    temp_value=lp_cube[LUF];
    lp_cube[LUF]=lp_cube[DLF];
    lp_cube[DLF]=lp_cube[RDF];
    lp_cube[RDF]=lp_cube[URF];
    lp_cube[URF]=temp_value;
    temp_value=lp_cube[FLU];
    lp_cube[FLU]=lp_cube[FDL];
    lp_cube[FDL]=lp_cube[FRD];
    lp_cube[FRD]=lp_cube[FUR];
    lp_cube[FUR]=temp_value;
    temp_value=lp_cube[UFL];
    lp_cube[UFL]=lp_cube[LFD];
    lp_cube[LFD]=lp_cube[DFR];
    lp_cube[DFR]=lp_cube[RFU];
    lp_cube[RFU]=temp_value;
    return lp_cube;
}
int *op_L1(int *cube) {
    return base_op_L(cube);
}
int *op_L2(int *cube) {
    return base_op_L(base_op_L(cube));
}
int *op_L3(int *cube) {
    return base_op_L(base_op_L(base_op_L(cube)));
}
int *op_U1(int *cube) {
    return base_op_U(cube);
}
int *op_U2(int *cube) {
    return base_op_U(base_op_U(cube));
}
int *op_U3(int *cube) {
    return base_op_U(base_op_U(base_op_U(cube)));
}
int *op_B1(int *cube) {
    return base_op_B(cube);
}
int *op_B2(int *cube) {
    return base_op_B(base_op_B(cube));
}
int *op_B3(int *cube) {
    return base_op_B(base_op_B(base_op_B(cube)));
}
int *op_R1(int *cube) {
    return base_op_R(cube);
}
int *op_R2(int *cube) {
    return base_op_R(base_op_R(cube));
}
int *op_R3(int *cube) {
    return base_op_R(base_op_R(base_op_R(cube)));
}
int *op_D1(int *cube) {
    return base_op_D(cube);
}
int *op_D2(int *cube) {
    return base_op_D(base_op_D(cube));
}
int *op_D3(int *cube) {
    return base_op_D(base_op_D(base_op_D(cube)));
}
int *op_F1(int *cube) {
    return base_op_F(cube);
}
int *op_F2(int *cube) {
    return base_op_F(base_op_F(cube));
}
int *op_F3(int *cube) {
    return base_op_F(base_op_F(base_op_F(cube)));
}
int* rot(int *cube,int i) {
    if(i==R1) {
        return op_R1(cube);
    }
    if(i==R2) {
        return op_R2(cube);
    }
    if(i==R3) {
        return op_R3(cube);
    }
    if(i==U1) {
        return op_U1(cube);
    }
    if(i==U2) {
        return op_U2(cube);
    }
    if(i==U3) {
        return op_U3(cube);
    }
    if(i==F1) {
        return op_F1(cube);
    }
    if(i==F2) {
        return op_F2(cube);
    }
    if(i==F3) {
        return op_F3(cube);
    }
    if(i==L1) {
        return op_L1(cube);
    }
    if(i==L2) {
        return op_L2(cube);
    }
    if(i==L3) {
        return op_L3(cube);
    }
    if(i==D1) {
        return op_D1(cube);
    }
    if(i==D2) {
        return op_D2(cube);
    }
    if(i==D3) {
        return op_D3(cube);
    }
    if(i==B1) {
        return op_B1(cube);
    }
    if(i==B2) {
        return op_B2(cube);
    }
    if(i==B3) {
        return op_B3(cube);
    }
}
