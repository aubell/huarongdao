int set_corner_color(int corner8, int c0, int c1, int c2) {
    int p[3];
    pieces_in(corner8,p);
    the_cube[p[0]]=c0;
    the_cube[p[1]]=c1;
    the_cube[p[2]]=c2;
}

int color_to_face(int c) {
    if(c==face_color[L])return L;
    if(c==face_color[U])return U;
    if(c==face_color[B])return B;
    if(c==face_color[R])return R;
    if(c==face_color[D])return D;
    if(c==face_color[F])return F;
}

int face_number_to_0124(int fn) {
    if(fn==L||fn==D||fn==B)return fn;
    return 0;
}

int color_3_to_corner(int c1, int c2, int c3) {
    int re=0;
    re = 0;
    re+=face_number_to_0124(color_to_face(c1));
    re+=face_number_to_0124(color_to_face(c2));
    re+=face_number_to_0124(color_to_face(c3));
    return re;
}

int cubie_to_face_3(int c,int *face) {
    if(c==0) {
        face[0]=U;
        face[1]=R;
        face[2]=F;
        return 1;
    }
    if(c==1) {
        face[0]=D;
        face[1]=F;
        face[2]=R;
        return 1;
    }
    if(c==2) {
        face[0]=U;
        face[1]=B;
        face[2]=R;
        return 1;
    }
    if(c==3) {
        face[0]=D;
        face[1]=R;
        face[2]=B;
        return 1;
    }
    if(c==4) {
        face[0]=U;
        face[1]=F;
        face[2]=L;
        return 1;
    }
    if(c==5) {
        face[0]=D;
        face[1]=L;
        face[2]=F;
        return 1;
    }
    if(c==6) {
        face[0]=U;
        face[1]=L;
        face[2]=B;
        return 1;
    }
    if(c==7) {
        face[0]=D;
        face[1]=B;
        face[2]=L;
        return 1;
    }
    return 0;
}

int cubie_to_color_3(int c,int *color) {
    int face[3];
    cubie_to_face_3(c,face);
    color[0]=face_color[face[0]];
    color[1]=face_color[face[1]];
    color[2]=face_color[face[2]];
}

int get_corner_at(int n) {
    int re=0;
    int c0=0;
    int c1=0;
    int c2=0;
    int p[3];
    pieces_in(n,p);
    c0=the_cube[p[0]];
    c1=the_cube[p[1]];
    c2=the_cube[p[2]];
    re=color_3_to_corner(c0, c1, c2) ;
    return re;
}

int get_corner_perm() {
    int i=0;
    int corners[]= {URF, DFR, UBR, DRB, UFL, DLF, ULB};
    int work[8];
    for(i=0; i<7; i++) {
        work[i]= get_corner_at(i);;
    }//end for
    return pack_perm(work,7);
}

int set_color_by_cubie_number(int loc, int n) {
    int p[3];
    int my_cube[24];
    reset_cube(my_cube);
    pieces_in(n,p);
    set_corner_color(loc,my_cube[p[0]],my_cube[p[1]],my_cube[p[2]]);
}

int set_corner_perm(int perm) {
    int i=0;
    int work[8];
    unpack_perm(perm,work,7);
    for(i=0; i<7; i++) {
        set_color_by_cubie_number(i,work[i]);
    }//end for
}

