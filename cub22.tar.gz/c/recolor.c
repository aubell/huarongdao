int op_color(int c) {
    if(c==YELLOW)return WHITE;
    if(c==WHITE) return YELLOW;
    if(c==GREEN) return BLUE;
    if(c==BLUE) return GREEN;
    if(c==RED) return ORANGE;
    if(c==ORANGE) return RED;
    return -1;
}

int recolor() {
    int i=0;
    int j=0;
    int sud=0;
    int sfb=0;
    int slr=0;
    face_color[D] = the_cube[DBL];
    face_color[B] = the_cube[BLD];
    face_color[L] = the_cube[LDB];
    face_color[R] = op_color(face_color[L]);
    face_color[F] = op_color(face_color[B]);
    face_color[U] = op_color(face_color[D]);
}

