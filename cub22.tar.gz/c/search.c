int search(int perm, int twist, int re) {
    int op=0;
    int st0=0;
    int new_perm=0;
    int new_twist=0;
    int dpt0=0;
    int dpt1=0;
    int new_st=0;
    int i=0;
    int iop=0;
    int op_tb[]= {R1, R2, R3, U1, U2, U3, F1, F2, F3};
    st0 = perm * 729 + twist;
    if((dpt0 = corner_perm_corner_twist_prun[st0])==0) {
        show_moves(reverse(re));
        return re;
    }//end if
    for(iop=0; iop<9; iop++) {
        new_perm = corner_perm_move_table[perm][iop];
        new_twist = corner_twist_move_table[twist][iop];
        new_st = new_perm * 729 + new_twist;
        dpt1 = corner_perm_corner_twist_prun[new_st];
        if ( dpt1<dpt0 ) {
            search(new_perm,new_twist,cons(iop,re));
        }//end if
    }//end for
}

