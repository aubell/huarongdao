int get_corner_twist() {
    return get_twist_6();
}

int set_corner_twist(int tw) {
    return set_twist_6(tw);
}

int corner_perm_move_table[5040][9];
int create_corner_perm_move_table() {
    int i=0;
    int face=0;
    int rpt=0;
    int iface=0;
    int tb[]= {R1, U1, F1};
    for(i=0; i<5040; i++) {
        reset_cube(the_cube);
        set_corner_perm(i);
        for(iface=0; iface<3; iface++) {
            face=tb[iface];
            for(rpt=0; rpt<4; rpt++) {
                rot(the_cube,face);
                if(rpt!=3)corner_perm_move_table[i][iface*3+rpt]=get_corner_perm();
            }//end for
        }//end for
    }//end for
}

int corner_twist_move_table[729][9];
int create_corner_twist_move_table() {
    int i=0;
    int face=0;
    int rpt=0;
    int iface=0;
    int tb[]= {R1, U1, F1};
    for(i=0; i<729; i++) {
        reset_cube(the_cube);
        set_corner_twist(i);
        for(iface=0; iface<3; iface++) {
            face=tb[iface];
            for(rpt=0; rpt<4; rpt++) {
                rot(the_cube,face);
                if(rpt!=3)corner_twist_move_table[i][iface*3+rpt]=get_corner_twist();
            }//end for
        }//end for
    }//end for
}

char corner_perm_corner_twist_prun[3674160];
int init_corner_perm_corner_twist_prun() {
    int i=0;
    for(i=0; i<3674160; i++) {
        corner_perm_corner_twist_prun[i]=-1;
    }//end for
}

int create_corner_perm_corner_twist_prun() {
    int corner_perm=0;
    int corner_twist=0;
    int dpt=0;
    int count=0;
    int iop=0;
    int total=0;
    int st=0;
    int op=0;
    int new_st=0;
    int new_corner_perm=0;
    int new_corner_twist=0;
    int op_tb[]= {R1, R2, R3, U1, U2, U3, F1, F2, F3};
    count = 0;
    total = 3674160;
    reset_cube(the_cube);
    init_corner_perm_corner_twist_prun();
    corner_perm = get_corner_perm();
    corner_twist = get_corner_twist();
    st = corner_perm*729 + corner_twist;
    corner_perm_corner_twist_prun[st] = 0;
    dpt = 0;
    ++count;
    while( count<total ) {
        for(corner_perm=0; corner_perm<5040; corner_perm++) {
            for(corner_twist=0; corner_twist<729; corner_twist++) {
                st = corner_perm*729 + corner_twist ;
                if( corner_perm_corner_twist_prun[st] == dpt ) {
                    for(iop=0; iop<9; iop++) {
                        new_corner_perm = corner_perm_move_table[corner_perm][iop];
                        new_corner_twist = corner_twist_move_table[corner_twist][iop];
                        new_st = new_corner_perm * 729 + new_corner_twist;
                        if(corner_perm_corner_twist_prun[new_st] ==  -1) {
                            corner_perm_corner_twist_prun[new_st]=dpt+1;    //end for
                            ++count;
                        }
                    }
                }//end if
            }//end for
        }//end for
        ++dpt;
    }//end while
}

