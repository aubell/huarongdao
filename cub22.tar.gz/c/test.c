

int show_moves(int cell) {
    int iop;
    char mvs[]= {'R','U','F'};

    if(null(cell)) {
        printf("\n");
        return NIL;
    }
    iop=car(cell);
    printf("%c", mvs[iop/3]);
    if((iop%3+1)==1)printf(" ");
    if((iop%3+1)==2)printf("2 ");
    if((iop%3+1)==3)printf("' ");
    return show_moves(cdr(cell));
}


int scramble(int *scr) {
    int op;
    while((op=*(scr++))!=NOP) {
        rot(the_cube,op);
    }
}

int solve(int *scr) {
    int twist,perm;
    int re;
    reset_colors();
    reset_cube(the_cube);
    scramble(scr);
    recolor();//???
    twist =get_corner_twist();
    perm = get_corner_perm();
    re= search(perm,twist,NIL);
    reset_cube(the_cube);
    reset_cells();
    printf("\n");
}



int scr_buf[1024];

int s6[]= {R1,U1,R3,U3,R3,F1,R2,U3,R3,U3,R1,U1,R3,F3,NOP};
int s7[]= {R1,U1,R3,U3,NOP};
int s8[]= {L1,D1,B1,R2,D1,NOP};
int main() {
    reset_colors();
    reset_cube(the_cube);
    reset_cells();
    create_corner_twist_move_table();
    create_corner_perm_move_table();
    create_corner_perm_corner_twist_prun();


    while(1) {
        printf("Scramble>>");
        read_input(scr_buf);
        printf("Solve>>\n");
        solve(scr_buf);
    }




//solve(s6);
//solve(s7);
//solve(s8);
}

