int corner_to_number[]= {0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7};
int location_twist_number[]= {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2};
int pieces_in(int c,int *face) {
    if(c==0) {
        face[0]=URF;
        face[1]=RFU;
        face[2]=FUR;
        return 1;
    }
    if(c==1) {
        face[0]=DFR;
        face[1]=FRD;
        face[2]=RDF;
        return 1;
    }
    if(c==2) {
        face[0]=UBR;
        face[1]=BRU;
        face[2]=RUB;
        return 1;
    }
    if(c==3) {
        face[0]=DRB;
        face[1]=RBD;
        face[2]=BDR;
        return 1;
    }
    if(c==4) {
        face[0]=UFL;
        face[1]=FLU;
        face[2]=LUF;
        return 1;
    }
    if(c==5) {
        face[0]=DLF;
        face[1]=LFD;
        face[2]=FDL;
        return 1;
    }
    if(c==6) {
        face[0]=ULB;
        face[1]=LBU;
        face[2]=BUL;
        return 1;
    }
    if(c==7) {
        face[0]=DBL;
        face[1]=BLD;
        face[2]=LDB;
        return 1;
    }
    return 0;
}

int is_ud_color(int c) {
    return ((c==face_color[U]) || (c==face_color[D]));
}

int get_single_twist(int c) {
    /*c form 0 to 7*/
    int color[3];
    int i=0;
    int re=0;
    int ppp=0;
    int main_color_at=0;
    int p[3];
    ppp = pieces_in(c,p);
    color[0]=the_cube[p[0]];
    color[1]=the_cube[p[1]];
    color[2]=the_cube[p[2]];
    for(i=0; i<3; i++) {
        if(is_ud_color(color[i])) {
            main_color_at=p[i];
            break;
        };
    }//end for
    return location_twist_number[main_color_at];
}

int set_single_twist(int c, int tw) {
    if(tw) {
        twist_corner(c);
    };
    if(tw==2) {
        twist_corner(c);
    };
    return tw;
}

int twist_urf() {
    int temp_value=0;
    temp_value=the_cube[URF];
    the_cube[URF]=the_cube[FUR];
    the_cube[FUR]=the_cube[RFU];
    the_cube[RFU]=temp_value;
}


int twist_dfr() {
    int temp_value=0;
    temp_value=the_cube[DFR];
    the_cube[DFR]=the_cube[RDF];
    the_cube[RDF]=the_cube[FRD];
    the_cube[FRD]=temp_value;
}


int twist_ubr() {
    int temp_value=0;
    temp_value=the_cube[UBR];
    the_cube[UBR]=the_cube[RUB];
    the_cube[RUB]=the_cube[BRU];
    the_cube[BRU]=temp_value;
}


int twist_drb() {
    int temp_value=0;
    temp_value=the_cube[DRB];
    the_cube[DRB]=the_cube[BDR];
    the_cube[BDR]=the_cube[RBD];
    the_cube[RBD]=temp_value;
}


int twist_ufl() {
    int temp_value=0;
    temp_value=the_cube[UFL];
    the_cube[UFL]=the_cube[LUF];
    the_cube[LUF]=the_cube[FLU];
    the_cube[FLU]=temp_value;
}


int twist_dlf() {
    int temp_value=0;
    temp_value=the_cube[DLF];
    the_cube[DLF]=the_cube[FDL];
    the_cube[FDL]=the_cube[LFD];
    the_cube[LFD]=temp_value;
}


int twist_ulb() {
    int temp_value=0;
    temp_value=the_cube[ULB];
    the_cube[ULB]=the_cube[BUL];
    the_cube[BUL]=the_cube[LBU];
    the_cube[LBU]=temp_value;
}


int twist_dbl() {
    int temp_value=0;
    temp_value=the_cube[DBL];
    the_cube[DBL]=the_cube[LDB];
    the_cube[LDB]=the_cube[BLD];
    the_cube[BLD]=temp_value;
}


int twist_corner(int piece) {
    if(piece==URF) {
        twist_urf();
        return 1;
    };
    if(piece==DFR) {
        twist_dfr();
        return 1;
    };
    if(piece==UBR) {
        twist_ubr();
        return 1;
    };
    if(piece==DRB) {
        twist_drb();
        return 1;
    };
    if(piece==UFL) {
        twist_ufl();
        return 1;
    };
    if(piece==DLF) {
        twist_dlf();
        return 1;
    };
    if(piece==ULB) {
        twist_ulb();
        return 1;
    };
    if(piece==DBL) {
        twist_dbl();
        return 1;
    };
    return 0;
}

int get_twist_6() {
    int re=0;
    int i=0;
    int len=6;;
    re=0;
    for(i=0; i<6; i++) {
        re*=3;
        re += get_single_twist(i);;
    }//end for
    return re;
}

int set_twist_6(int tw) {
    int i=0;
    int my_twist=0;
    int cnt=0;
    int len=6;
    cnt=0;
    for(i=5; i>=0; i--) {
        my_twist= tw%3;
        tw/=3;
        set_single_twist(i,my_twist);
        cnt+=my_twist;
        cnt%=3;
    }//end for
    ;
    set_single_twist(ULB,(3-cnt)%3);
    /*the last one beyond these must mod 3 to check!*/;
    return tw;
}

